## Task 2: Video Listing

Creating Frontend design using HTML, CSS and Bootstrap.

## Screenshot


## 1440px

<img src="../Readme-Images/task4-desktop.png" />

---

## 768px

<img src="../Readme-Images/task4-tab.png" />

---

## 378px

<img src="../Readme-Images/task4-mobile.png" />

---